
// Author: Maryam Afshar 040885113
// Assignment: 2
// Date: JuLY 24, 2021
// Professor: Daniel Cormier
// Purpose: To make the dialog box
// Class list: OthelloNetworkModelView
package othello;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.border.MatteBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

/**
 * Purpose: OthelloViewController will assemble the UI
 * 
 * @author Maryam Afshar
 * @version 1
 * @see othello
 * @since "1.8.0_231"
 */

public class OthelloViewController extends JFrame implements ActionListener, MenuListener {
	/**
	 * variable declaration for serial ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * variable declaration for array for board
	 */
	public JLabel[][] gameBoard = new JLabel[10][10];

	String[] alpha = { "A", "B", "C", "D", "E", "F", "G", "H" };
	int counter = 0;
	int abc = 0;
	OthelloModel oModel = new OthelloModel();
	JTextArea blueText;

	// Panel for the board

	public JPanel board;

	/**
	 * Constructor purpose: all UI sector is in constructor and everything
	 */

	public OthelloViewController() {
		// creating 5 main JPanel
		JPanel mainS = new JPanel();// Create the main section

		JPanel leftS = new JPanel();// create the left section

		// start the Othello board
		ImageIcon whiteB = new ImageIcon("/pic/white.png");
		ImageIcon blackB = new ImageIcon("/pic/black.png");

		leftS.setLayout(new BorderLayout());

		board = new JPanel();

		board.setPreferredSize(new Dimension(600, 600)); // 60 * 8 = 480, making squares 60x60 and 2 more columns
		board.setBackground(new Color(220, 220, 220));

		board.setBorder(BorderFactory.createLineBorder(Color.gray));

		board.setLayout(new GridLayout(10, 10));

		// Creating the othello board game using two for loop to show the board

		for (int i = 0; i < 10; i++) {

			for (int j = 0; j < 10; j++) {

				if ((i + j + 1) % 2 == 0) {

					gameBoard[i][j] = new JLabel();
					gameBoard[i][j].setOpaque(true);
					gameBoard[i][j].setBackground(Color.BLACK);
					board.add(gameBoard[i][j]);

				} else {
					gameBoard[i][j] = new JLabel();
					gameBoard[i][j].setOpaque(true);
					gameBoard[i][j].setBackground(Color.white);
					board.add(gameBoard[i][j]);
				}

				if (i == 0 || i == 9) {// make the row 0 and 9 disabeled
					if (j != 0 && j != 9)
						gameBoard[i][j].setText((j) + " ");
					gameBoard[i][j].setBackground(new Color(220, 220, 220));
					gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
				}

				// adding the 4 chips at the center of the board 4 for loop used to show each of
				// the them

				if (i == 4 && j == 4) {// adding the first chip in [4][4]

					ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
					JLabel chip = new JLabel(white);
					chip.setIcon(white);
					gameBoard[4][4].setIcon(white);
					gameBoard[4][4].setHorizontalAlignment(JLabel.CENTER);

				}

				if (i == 5 && j == 5) {// adding chip in [5]54]

					ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
					JLabel chip = new JLabel(white);
					chip.setIcon(white);
					gameBoard[5][5].setIcon(white);
					gameBoard[5][5].setHorizontalAlignment(JLabel.CENTER);
				}

				if (i == 4 && j == 5) {// adding chip in [4][5]

					ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
					JLabel chip = new JLabel(black);
					chip.setIcon(black);
					gameBoard[4][5].setIcon(black);
					gameBoard[4][5].setHorizontalAlignment(JLabel.CENTER);
				}

				if (i == 5 && j == 4) {// adding chip in [5][4]

					ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
					JLabel chip = new JLabel(black);
					chip.setIcon(black);
					gameBoard[5][4].setIcon(black);
					gameBoard[5][4].setHorizontalAlignment(JLabel.CENTER);
				}

				// adding the alphabet labels
				if (j == 0 || j == 9) {
					if (i != 0 && i != 9) {
						char c;

						gameBoard[i][j].setText(alpha[counter]);

						abc++;
						if (abc == 2) {
							counter++;
							abc = 0;
						}

					}
					gameBoard[i][j].setBackground(new Color(220, 220, 220));
					gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

				}
			}

		}

		leftS.add(board, BorderLayout.NORTH);
		JPanel rightS = new JPanel();// create right section
		JPanel bottomS = new JPanel();// create bottom Section

		// start of creating 2 components of bottom section which is a button and
		// textField

		// Create a button in bottom section to submit
		JButton blackBox = new JButton("Submit");

		// set background color of button
		blackBox.setBackground(Color.black);

		// set color of text inside blackbox
		blackBox.setForeground(Color.RED);

		// create a textField at bottom part of main section
		JTextField bottomL = new JTextField();

		// create a borderLayout in main section
		mainS.setLayout(new BorderLayout());

		// set the background color to grey
		mainS.setBackground(new Color(220, 220, 220));

		// set the border color to grey and thickness to 5
		mainS.setBorder(BorderFactory.createLineBorder(Color.gray, 5));

		// create a borderLayout in bottom part of main section
		bottomS.setLayout(new BorderLayout());

		// add the black box to bottom section and be at right
		bottomS.add(blackBox, BorderLayout.EAST);

		// add the textField to bottom section and set it to be in center
		bottomS.add(bottomL, BorderLayout.CENTER);

		// add the bottom section to the main section and put it at the south of main
		// section
		mainS.add(bottomS, BorderLayout.SOUTH);
		add(mainS);

		// end of bottom section

		/**
		 * start of creating right section
		 * 
		 * create a borderLayout in right part of main section
		 */

		rightS.setLayout(new BorderLayout());

		// set a preferred size for right section
		rightS.setPreferredSize(new Dimension(450, 30));

		/**
		 * Creating three JPanel in right section creating a check box at the very top
		 * of right section of main
		 */

		JCheckBox right1 = new JCheckBox("Show Valid Moves");
		JPanel r1 = new JPanel();
		JPanel r2 = new JPanel();
		JPanel r3 = new JPanel();

		/*
		 * adding first part r1 to the right section creating new border layout in right
		 * section adding check box to first section
		 */
		rightS.add(r1, BorderLayout.NORTH);
		r1.setLayout(new BorderLayout());
		r1.add(right1);

		// Creating text area in part two of right section
		blueText = new JTextArea("Player 1 initialized with 2 pieces.");

		blueText.setBackground(new Color(175, 175, 255));
		blueText.append("\nPlayer 2 initialized with 2 pieces.");
		blueText.setEditable(false);

		// add the blue text part at south of right section
		rightS.add(r2, BorderLayout.SOUTH);

		// set background color
		r2.setBackground(new Color(175, 175, 255));

		// set size
		r2.setPreferredSize(new Dimension(450, 390));

		// add the blue text to south section in right
		r2.add(blueText);
		r2.setBorder(new MatteBorder(5, 0, 5, 0, Color.GRAY));

		/*
		 * start of center part of right section 3 parts in center part creating 3 part
		 * in r3
		 */
		JPanel r3L = new JPanel();
		JPanel r3R = new JPanel();
		JPanel r3C = new JPanel();

		// create 2 JPanel in right section of r3
		JPanel r3RN = new JPanel();
		JPanel r3RS = new JPanel();

		ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));

		// creating new JLabel
		JLabel whitePic = new JLabel(white);
		JTextField whiteNum = new JTextField("2");
		whiteNum.setBackground(new Color(220, 220, 220));
		whiteNum.setEditable(false);
		whiteNum.setBorder(null);

		r3RN.add(whitePic);
		r3RN.add(whiteNum);
		r3RN.setBackground(new Color(220, 220, 220));

		// creating image icon
		ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
		JLabel blackPic = new JLabel(black);
		JTextField blackNum = new JTextField("2");

		// set the background color
		blackNum.setBackground(new Color(220, 220, 220));
		blackNum.setEditable(false);
		blackNum.setBorder(null);

		r3RS.add(blackPic);
		r3RS.add(blackNum);
		r3RS.setBackground(new Color(220, 220, 220));

		// creating grid layout with 3 rows and 1 column
		r3R.setLayout(new GridLayout(3, 1));

		// creating new JPanel
		JPanel e = new JPanel();
		e.setBackground(new Color(220, 220, 220));
		r3R.add(e);
		r3R.add(r3RN);
		r3R.add(r3RS);

		// creating grid layout at the center of r3
		r3C.setLayout(new GridLayout(3, 1));
		e = new JPanel();

		e.setBackground(new Color(220, 220, 220));
		r3C.add(e);

		// creating text field

		JTextField p1 = new JTextField("Player 1 Pieces:");
		p1.setEditable(false);
		p1.setBackground(new Color(220, 220, 220));
		p1.setBorder(null);

		// create textField

		JTextField p2 = new JTextField("Player 2 Pieces:");
		p2.setEditable(false);
		p2.setBackground(new Color(220, 220, 220));
		p2.setBorder(null);

		r3C.add(p1);
		r3C.add(p2);

		r3L.setLayout(new GridLayout(3, 3, 3, 3));

		JButton empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		JButton up = new JButton(new ImageIcon(this.getClass().getResource("/pic/uparrow.png")));
		up.setPreferredSize(new Dimension(40, 40));
		up.setBackground(Color.WHITE);
		r3L.add(up);

		empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		JButton left = new JButton(new ImageIcon(this.getClass().getResource("/pic/leftarrow.png")));
		left.setPreferredSize(new Dimension(40, 40));
		left.setBackground(Color.WHITE);
		r3L.add(left);

		JButton move = new JButton("move");
		move.setPreferredSize(new Dimension(40, 40));
		move.setMargin(new Insets(0, 0, 0, 0));
		move.setBackground(Color.WHITE);
		r3L.add(move);

		JButton right = new JButton(new ImageIcon(this.getClass().getResource("/pic/rightarrow.png")));
		right.setPreferredSize(new Dimension(40, 40));
		right.setBackground(Color.WHITE);
		r3L.add(right);

		empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		// create new botton

		JButton down = new JButton(new ImageIcon(this.getClass().getResource("/pic/downarrow.png")));
		down.setBackground(Color.WHITE);
		down.setPreferredSize(new Dimension(40, 40));
		r3L.add(down);

		empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		r3L.setBackground(new Color(220, 220, 220));

		r3.setLayout(new FlowLayout());
		r3.setBackground(new Color(220, 220, 220));

		r3.add(r3L);
		r3.add(r3C);
		r3.add(r3R);

		r3.setBorder(new MatteBorder(5, 0, 0, 0, Color.GRAY));

		rightS.add(r3, BorderLayout.CENTER);

		rightS.setBorder(new MatteBorder(0, 5, 0, 0, Color.GRAY));
		mainS.add(rightS, BorderLayout.EAST);
		mainS.add(leftS, BorderLayout.WEST);

		JMenuItem saveItem;
		JMenuItem newGameItem;
		JMenuItem exitItem;
		JCheckBoxMenuItem readonlyItem;
		JPopupMenu popup;

		JMenuBar mbar = new JMenuBar();
		setJMenuBar(mbar);

		// demonstrates how to enabled/disabled items
		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');
		// fileMenu.addMenuListener(this);

		// demonstrates how to add accelerators
		JMenuItem loadItem = new JMenuItem("Load");
		loadItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
		loadItem.setEnabled(false);
		saveItem = new JMenuItem("Save");
		saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));

		saveItem.setEnabled(false);

		exitItem = new JMenuItem("Exit");
		exitItem.setAccelerator(
				KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK + InputEvent.ALT_DOWN_MASK));

		newGameItem = new JMenuItem("New Game");

		newGameItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F7, InputEvent.ALT_DOWN_MASK));

		mbar.add(buildMenu(fileMenu, new Object[] { newGameItem, null, saveItem, loadItem, null, exitItem, }, this));

		// creating group button

		ButtonGroup group = new ButtonGroup();

		JRadioButtonMenuItem normal = new JRadioButtonMenuItem("Normal Game");
		normal.addActionListener(this);
		normal.setSelected(true);

		JRadioButtonMenuItem corner = new JRadioButtonMenuItem("Corner Test");
		corner.addActionListener(this);

		JRadioButtonMenuItem side = new JRadioButtonMenuItem("Side Tests");
		side.addActionListener(this);

		JRadioButtonMenuItem capture1 = new JRadioButtonMenuItem("1 * Capture Test");
		capture1.addActionListener(this);

		JRadioButtonMenuItem capture2 = new JRadioButtonMenuItem("2 * Capture Test");
		capture2.addActionListener(this);

		JRadioButtonMenuItem emptyB = new JRadioButtonMenuItem("Empty Board");
		emptyB.addActionListener(this);

		JRadioButtonMenuItem innerS = new JRadioButtonMenuItem("Inner Square Test");
		innerS.addActionListener(this);

		JRadioButtonMenuItem upArrow = new JRadioButtonMenuItem("Up Arrow Orientation Test");
		upArrow.addActionListener(this);

		group.add(normal);
		group.add(corner);
		group.add(side);
		group.add(capture1);
		group.add(capture2);
		group.add(emptyB);
		group.add(innerS);
		group.add(upArrow);

		// buid submenu which is debug Scenarios
		JMenu debug = new JMenu("Debug Scenarios");

		debug.addSeparator();
		debug.add(normal);
		debug.add(corner);
		debug.add(side);
		debug.add(capture1);
		debug.add(capture2);
		debug.add(emptyB);
		debug.add(innerS);
		debug.add(upArrow);

		// creating submenu board Colours which has 3 choices
		JMenu boardC = new JMenu("Board Colours");

		ButtonGroup group1 = new ButtonGroup();

		JRadioButtonMenuItem bw = new JRadioButtonMenuItem("Black & White");
		bw.addActionListener(this);
		normal.setSelected(true);

		JRadioButtonMenuItem canadianC = new JRadioButtonMenuItem("Red & white");
		canadianC.addActionListener(this);

		JRadioButtonMenuItem myChoice = new JRadioButtonMenuItem("my Choice");
		myChoice.addActionListener(this);

		group.add(bw);
		group.add(canadianC);
		group.add(myChoice);

		boardC.add(bw);
		boardC.add(canadianC);
		boardC.add(myChoice);
		boardC.addActionListener(this);
		mbar.add(buildMenu("Game", new Object[] { null, boardC, null, debug, }, this));
		// buildmenu.setMnemonic('N');

		JMenu netMenu = new JMenu("Network");
		netMenu.setMnemonic('N');

		mbar.add(buildMenu(netMenu, new Object[] { // new JMenuItem("Index", 'I'),
				new JMenuItem("New Connection", 'N') }, this));

		mbar.add(buildMenu(netMenu, new Object[] { // new JMenuItem("Index", 'I'),
				new JMenuItem("Disconnect", 'D') }, this));

		// demonstrate Help menu

		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');

		mbar.add(buildMenu(helpMenu, new Object[] { // new JMenuItem("Index", 'I'),
				new JMenuItem("About", 'A') }, this));

	}

//	class Controller implements ActionListener{

//	}
	@Override
	/**
	 * actionPerformed executes actions of items on GUI
	 */
	public void actionPerformed(ActionEvent evt) {

		// about
		String arg = evt.getActionCommand();

		System.out.println(arg);
		if (evt.getActionCommand().equals("About")) {
			JOptionPane.showMessageDialog(this, "Othello Game \n By Maryam Afshar \n\n July 15 ", "About",
					JOptionPane.INFORMATION_MESSAGE);
		}

		// Exit in sub menu
		if (arg.equals("Exit")) {
			this.dispose();
			System.exit(0);

		}
		// changes the color of board to red and white
		if (arg.equals("Red & white")) {

			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					if ((i + j + 1) % 2 == 0) {

						gameBoard[i][j].setOpaque(true);
						gameBoard[i][j].setBackground(Color.red);
						board.add(gameBoard[i][j]);

					} else {

						gameBoard[i][j].setOpaque(true);
						gameBoard[i][j].setBackground(Color.white);
						board.add(gameBoard[i][j]);
					}

					if (i == 0 || i == 9) {
						if (j != 0 && j != 9)
							gameBoard[i][j].setText((j) + " ");
						gameBoard[i][j].setBackground(new Color(220, 220, 220));
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
					}

					if (j == 0 || j == 9) {
						if (i != 0 && i != 9) {
							char c;

							gameBoard[i][j].setBackground(new Color(220, 220, 220));
							gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
						}
					}
				}

			}

		}
		// change the color of board to pink
		if (arg.equals("my Choice")) {

			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					if ((i + j + 1) % 2 == 0) {

						gameBoard[i][j].setOpaque(true);
						gameBoard[i][j].setBackground(Color.pink);
						board.add(gameBoard[i][j]);

					} else {

						gameBoard[i][j].setOpaque(true);
						gameBoard[i][j].setBackground(Color.white);
						board.add(gameBoard[i][j]);
					}

					if (i == 0 || i == 9) {
						if (j != 0 && j != 9)
							gameBoard[i][j].setText((j) + " ");
						gameBoard[i][j].setBackground(new Color(220, 220, 220));
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
					}

					if (j == 0 || j == 9) {
						if (i != 0 && i != 9) {
							char c;

							gameBoard[i][j].setBackground(new Color(220, 220, 220));
							gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
						}
					}

				}

			}
		}

		// change the color of board to black and white which is default color
		if (arg.equals("Black & White")) {

			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					if ((i + j + 1) % 2 == 0) {

						gameBoard[i][j].setOpaque(true);
						gameBoard[i][j].setBackground(Color.black);
						board.add(gameBoard[i][j]);

					} else {

						gameBoard[i][j].setOpaque(true);
						gameBoard[i][j].setBackground(Color.white);
						board.add(gameBoard[i][j]);
					}

					if (i == 0 || i == 9) {
						if (j != 0 && j != 9)

							gameBoard[i][j].setText((j) + " ");
						gameBoard[i][j].setBackground(new Color(220, 220, 220));
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
					}

					if (j == 0 || j == 9) {
						if (i != 0 && i != 9) {
							char c;

							gameBoard[i][j].setBackground(new Color(220, 220, 220));
							gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
						}
					}

				}

			}

		}

		// it shows the corner Model on board game
		if (arg.equals("Corner Test")) {

			oModel.prepareBoard(OthelloModel.CORNER_TEST);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);
					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}

				}

			}

		} // corner

		// it shows the Up Arrow Orientation Model on board game

		if (arg.equals("Up Arrow Orientation Test")) {

			oModel.prepareBoard(OthelloModel.ARROW);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // up arrow

		// it shows the Inner Square Test Model on board game

		if (arg.equals("Inner Square Test")) {

			oModel.prepareBoard(OthelloModel.INNER_TEST);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // inner

		// it shows the 1 * Capture Model on board game

		if (arg.equals("1 * Capture Test")) {

			oModel.prepareBoard(OthelloModel.TEST_CAPTURE);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // capture 1

		// it shows the 2 * Capture Model on board game

		if (arg.equals("2 * Capture Test")) {

			oModel.prepareBoard(OthelloModel.TEST_CAPTURE2);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // capture 1

		// it shows the side tests Model on board game

		if (arg.equals("Side Tests")) {

			oModel.prepareBoard(OthelloModel.OUTER_TEST);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // side test

		// it shows the empty Model on board game

		if (arg.equals("Empty Board")) {

			oModel.prepareBoard(OthelloModel.UNWINNABLE);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // empty

		// it shows the Normal Model on board game
		if (arg.equals("Normal Game")) {

			oModel.prepareBoard(OthelloModel.NORMAL);
			for (int i = 0; i < 10; i++) {

				for (int j = 0; j < 10; j++) {

					int playerType = oModel.getSquare(i, j);
					if (playerType == 2) {
						ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));
						JLabel chip = new JLabel(white);
						chip.setIcon(white);
						gameBoard[i][j].setIcon(white);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					} else if (playerType == 1) {
						ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
						JLabel chip = new JLabel(black);
						chip.setIcon(black);
						gameBoard[i][j].setIcon(black);
						gameBoard[i][j].setHorizontalAlignment(JLabel.CENTER);

					}

					else if (playerType != 1 || playerType != 2) {
						gameBoard[i][j].setIcon(null);
					}
				}

			}

		} // Normal

		// prints the disconnect on blue text area
		if (arg.equals("Disconnect")) {

			blueText.append("\nDisconnecting..");

		} // disconnect
			// start New Connection
		if (evt.getActionCommand().equals("New Connection")) {
			OthelloNetworkModalViewController networkDialog = new OthelloNetworkModalViewController(this);

			Point thisLocation = getLocation(); // Gets location of Othello.
			Dimension parentSize = getSize(); // gets Size of Othello
			Dimension dialogSize = networkDialog.getSize();

			System.out.println(dialogSize);

			int offsetX = (parentSize.width - dialogSize.width) / 2 + thisLocation.x;
			int offsetY = (parentSize.height - dialogSize.height) / 2 + thisLocation.y;
			networkDialog.setLocation(offsetX, offsetY);
			networkDialog.setPreferredSize(new Dimension(1000, 1000));
			networkDialog.setVisible(true);

			if (networkDialog.pressedConnect() == true) {
				blueText.append("\nConnecting to " + networkDialog.getAddress());
				blueText.append("\nOn Port " + networkDialog.getPort());
				blueText.append("\nWith name" + networkDialog.getName());
			} else {
				blueText.append("\nCancel pressed");
			}
		}

	}

	/**
	 * Creates a menu with menu items.
	 * 
	 * @param parent       which adds items to the menu.
	 * @param items        that list of references to menu items names (strings).
	 * @param eventHandler event handler for the menu items.
	 * @returns a reference to JMenu with optional menu items.
	 * 
	 */
	private JMenu buildMenu(Object parent, Object[] items, Object eventHandler) {
		JMenu m = null;
		if (parent instanceof JMenu)
			m = (JMenu) parent;
		else if (parent instanceof String)
			m = new JMenu((String) parent);
		else
			return null;
		if (items == null)
			return null;
		for (int i = 0; i < items.length; i++) {
			if (items[i] == null)
				m.addSeparator();
			else
				m.add(buildMenuItem(items[i], eventHandler));
		}

		return m;
	}

	/**
	 * Creates a menu item.
	 * 
	 * @param parent       the parent is a instance of JMenuItem it adds an event
	 *                     handler.
	 * @param eventHandler event handler for the menu items.
	 * @returns a reference to JMenuItem.
	 * 
	 */
	private JMenuItem buildMenuItem(Object item, Object eventHandler) {
		JMenuItem r = null;
		if (item instanceof String)
			r = new JMenuItem((String) item);
		else if (item instanceof JMenuItem)
			r = (JMenuItem) item;
		else
			return null;

		if (eventHandler instanceof ActionListener)
			r.addActionListener((ActionListener) eventHandler);
		else
			return null;
		return r;
	}

	@Override
	public void menuCanceled(MenuEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void menuDeselected(MenuEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void menuSelected(MenuEvent arg0) {
		// TODO Auto-generated method stub

	}
}
