// Author: Maryam Afshar 040885113
// Assignment: 2
// Date: JuLY 24, 2021
// Professor: Daniel Cormier
// Purpose: To check the debugs and how the game works
// Class list: OthelloModel


package othello;

/**
 * Here is a stub of the OthelloModel, containing all the test boards listed in
 * in the assignment file for your implementation.
 * @author Maryam Afshar
 * @version 1
 * @see othello
 * @since "1.8.0_231"

 * 
 */
public class OthelloModel {

	private int[][] board;

	// Some class constants for your use:
	public static final int NORMAL = 0;
	public static final int CORNER_TEST = 1;
	public static final int OUTER_TEST = 2;
	public static final int TEST_CAPTURE = 3;
	public static final int TEST_CAPTURE2 = 4;
	public static final int UNWINNABLE = 5;
	public static final int INNER_TEST = 6;
	public static final int ARROW = 7;
	public static final int CUSTOM = 9;
	public static final int EMPTY = 0;
	public static final int BLACK = 1;
	public static final int WHITE = 2;

	/**
	 * Default constructor prepares a normal game.
	 */
	public OthelloModel() {
		prepareBoard(NORMAL);
	}
     
	/**
	 * purpose:This method contains several different board layouts to test portions of the code
	 * @param mode that shows different testing scenarios 
	 */
	public void prepareBoard(int mode) {
		switch (mode) {
		case CUSTOM:
			board = new int[][] { 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0,0, 2, 1, 0, 2, 0, 0, 1 ,0},
				{0, 2, 0, 0, 0, 0, 0, 2, 0,0 }, 
				{0, 1, 0, 1, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 1, 0, 0, 0, 0, 1, 0,0 }, 
				{0, 2, 0, 0, 0, 0, 0, 0, 2,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }};
			break;

		case CORNER_TEST:
			board = new int[][] { 
				    {0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				    {0, 2, 0, 0, 0, 0, 0, 0, 1,0 },
				    {0, 0, 1, 0, 0, 0, 0, 2, 0,0 }, 
				    {0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
					{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
                    {0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
                    {0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
					{0, 0, 1, 0, 0, 0, 0, 1, 0,0 }, 
					{0, 2, 0, 0, 0, 0, 0, 0, 2,0 } ,
					{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },};
			break;

		case OUTER_TEST:
			board = new int[][] { 
			    {0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 2, 2, 2, 2, 2, 2, 0,0 }, 
				{0, 0, 2, 1, 1, 1, 1, 2, 0,0 },
			    {0, 0, 2, 1, 0, 0, 1, 2, 0,0 }, 
				{0, 0, 2, 1, 0, 0, 1, 2, 0,0 }, 
				{0, 0, 2, 1, 1, 1, 1, 2, 0,0 },
				{0, 0, 2, 2, 2, 2, 2, 2, 0,0 }, 
			    {0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },};
			break;

		case INNER_TEST:
			board = new int[][] { 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 2, 2, 2, 2, 2, 2, 2, 2,0 }, 
				{0, 2, 0, 0, 0, 0, 0, 0, 2,0 }, 
				{0, 2, 0, 2, 2, 2, 2, 0, 2,0 },
				{0, 2, 0, 2, 1, 1, 2, 0, 2,0 }, 
				{0, 2, 0, 2, 1, 1, 2, 0, 2,0 }, 
				{0, 2, 0, 2, 2, 2, 2, 0, 2,0 },
				{0, 2, 0, 0, 0, 0, 0, 0, 2,0 }, 
				{0, 2, 2, 2, 2, 2, 2, 2, 2,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },};
			break;

		case UNWINNABLE:
			board = new int[][] { 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0}, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },};
			break;

		case TEST_CAPTURE:
			board = new int[][] { 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 1, 1, 1, 1, 1, 1, 0,0 }, 
				{0, 0, 1, 1, 1, 1, 1, 1, 0,0 },
				{0, 0, 1, 2, 2, 2, 1, 1, 0,0 }, 
				{0, 0, 1, 2, 0, 2, 1, 1, 0,0 }, 
				{0, 0, 1, 2, 2, 2, 1, 1, 0,0 },
				{0, 0, 1, 1, 1, 1, 1, 1, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 } };
			break;

		case TEST_CAPTURE2:
			board = new int[][] {
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 1, 1, 1, 1, 1, 1, 1, 1,0 }, 
				{0, 1, 1, 1, 1, 1, 1, 1, 1,0 }, 
				{0, 1, 2, 2, 2, 1, 2, 1, 1,0 },
				{0, 1, 2, 2, 2, 2, 2, 1, 1,0 }, 
				{0, 1, 2, 2, 0, 2, 2, 1, 1,0 }, 
				{0, 1, 2, 2, 2, 2, 1, 1, 1,0 },
				{0, 1, 2, 1, 2, 2, 2, 1, 1,0 }, 
				{0, 1, 1, 1, 1, 1, 1, 1, 1,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },};
			break;

		case ARROW:
			board = new int[][] { 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 1, 1, 0, 0, 0,0 }, 
				{0,0, 0, 1, 1, 1, 1, 0, 0,0 }, 
				{0, 0, 1, 0, 1, 1, 0, 1, 0,0 },
				{0, 1, 0, 0, 1, 1, 0, 0, 1,0 }, 
				{0, 0, 0, 0, 1, 1, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 1, 1, 0, 0, 0,0 },
				{0, 0, 0, 0, 1, 1, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 1, 1, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },};
			break;

		default:
			board = new int[][] { 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 2, 1, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 1, 2, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }, 
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 },
				{0, 0, 0, 0, 0, 0, 0, 0, 0,0 }};
		}
	}

	// 
/**
 * Purpose: This method returns the contents of a given square (0 for empty, 1 for black, 2 
 * @param row is the row of the board
 * @param col is the column of the board
 * @return board[row][col]
 */
	public int getSquare(int row, int col) {
		return board[row][col];

	}

	/**
	 * Purpose: This logic will check to see if a player (1 for black, 2 for white) may make a valid move
       at that particular square. True if yes, false if no. 
	 * @param row of the game board 
	 * @param col of the board game
	 * @param player in game
	 * @return true
	 */
	public boolean canMove(int row, int col, int player) {

		if (board[row][col] != 0) { // if the position is not empty can't move
			return false;
		}

		return true;

	}
/**
 * Purpose:The player is trying to move at the specified square.
 * @param row of the game board 
 * @param col of the game board 
 * @param player in game 
 * @return Return the number of chips captured, 0 for an invalid move.
 */
	
	public int tryMove(int row, int col, int player) {

		int enemy, counter = 0;
		if (player == 1)
			enemy = 2;
		else
			enemy = 1;

		if (board[row][col] != 0) { // if the position is not empty can't move
			return 0;
		}

		if (row == 0 && col == 0) {
			if (board[row][col + 1] != enemy && board[row + 1][col] != enemy && board[row + 1][col + 1] != enemy) {
				return 0;
			} else {
				if (board[row][col + 1] == enemy && board[row][col + 2] == player) {
					counter++;
					board[row][col + 1] = player;
				}
				if (board[row + 1][col] == enemy && board[row + 2][col] == player) {
					counter++;
					board[row + 1][col] = player;
				}
				if (board[row + 1][col + 1] == enemy && board[row + 2][col + 2] == player) {
					counter++;
					board[row + 1][col + 1] = player;
				}
			}

		} else if (row == 0 && col == 7) {
			if (board[row][col - 1] != enemy && board[row + 1][col] != enemy && board[row + 1][col - 1] != enemy) {
				return 0;
			} else {
				if (board[row][col - 1] == enemy && board[row][col - 2] == player) {
					counter++;
					board[row][col - 1] = player;
				}
				if (board[row + 1][col] == enemy && board[row + 2][col] == player) {
					counter++;
					board[row + 1][col] = player;
				}
				if (board[row + 1][col - 1] == enemy && board[row + 2][col - 2] == player) {
					counter++;
					board[row + 1][col - 1] = player;
				}
			}

		} else if (row == 7 && col == 0) {
			if (board[row][col + 1] != enemy && board[row - 1][col] != enemy && board[row - 1][col + 1] != enemy) {
				return 0;
			} else {
				if (board[row][col + 1] == enemy && board[row][col + 2] == player) {
					counter++;
					board[row][col + 1] = player;
				}
				if (board[row - 1][col] == enemy && board[row - 2][col] == player) {
					counter++;
					board[row - 1][col] = player;
				}
				if (board[row - 1][col + 1] == enemy && board[row - 2][col + 2] == player) {
					counter++;
					board[row - 1][col + 1] = player;
				}
			}

		} else if (row == 7 && col == 7) {
			if (board[row][col - 1] != enemy && board[row - 1][col] != enemy && board[row - 1][col - 1] != enemy) {
				return 0;
			} else {
				if (board[row][col - 1] == enemy && board[row][col - 2] == player) {
					counter++;
					board[row][col - 1] = player;
				}
				if (board[row - 1][col] == enemy && board[row - 2][col] == player) {
					counter++;
					board[row - 1][col] = player;
				}
				if (board[row - 1][col - 1] == enemy && board[row - 2][col - 2] == player) {
					counter++;
					board[row - 1][col - 1] = player;
				}
			}

		} else if (row == 0) {
			if (board[row][col - 1] != enemy && board[row][col + 1] != enemy && board[row + 1][col] != enemy
					&& board[row + 1][col - 1] != enemy && board[row + 1][col + 1] != enemy) {
				return 0;
			} else {
				if (board[row][col - 1] == enemy && board[row][col - 2] != player) {
					counter++;
					board[row][col - 1] = player;
				}

			}

		} else if (row == 7) {
			if (board[row][col - 1] != enemy && board[row][col + 1] != enemy && board[row - 1][col] != enemy
					&& board[row - 1][col - 1] != enemy && board[row - 1][col + 1] != enemy) {
				return 0;
			}
		} else if (col == 0) {
			if (board[row][col + 1] != enemy && board[row - 1][col] != enemy && board[row + 1][col] != enemy
					&& board[row - 1][col + 1] != enemy && board[row + 1][col + 1] != enemy) {
				return 0;
			}
		} else if (col == 7) {
			if (board[row][col - 1] != enemy && board[row - 1][col] != enemy && board[row + 1][col] != enemy
					&& board[row - 1][col - 1] != enemy && board[row + 1][col - 1] != enemy) {
				return 0;
			}
		} else {
			if (board[row][col - 1] != enemy && board[row][col + 1] != enemy && board[row - 1][col] != enemy
					&& board[row + 1][col] != enemy && board[row - 1][col - 1] != enemy
					&& board[row - 1][col + 1] != enemy && board[row + 1][col - 1] != enemy
					&& board[row + 1][col + 1] != enemy) {
				return 0;
			}
		}

		return counter;

	}
/**
 * Purpose:  If there exists ANY valid move for that player
 * @param player
 * @return true if it's a valid move 
 */
	
	public boolean moveTest(int player) {
		return false;

	}
/**
 * Purpose: How many chips does the specified player have in play
 * @param player in game
 * @return Player
 */
	
	public int chipCount(int player) {
		
		
		return player;

	}
	/**
	 * Purpose: thsi method prints the board
	 */

	public void printBoard() {
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				System.out.print(board[i][j] + " ");

			}
			System.out.println();
		}
	}

}

