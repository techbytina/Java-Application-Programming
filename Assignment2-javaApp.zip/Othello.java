//File name: Othello.java
//Author: Maryam Afshar 040885113 
//Assignment: 1 
//Date: June 26, 2021
//Professor: Daniel Cormier
//Purpose: To run othello board and splash screen
//Class list: Othello

package othello;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;

/**
 * Othello starts the othello game and shows the splash screen
 * 
 * @author Maryam Afshar
 * @version 1
 * @see othello
 * @since "1.8.0_231"
 */

public class Othello {
	/**
	 * Purpose: main method runs the program
	 * 
	 * @param args which is for main method
	 */
	public static void main(String[] args) {

		int duration = 5000;
		if (args.length == 1) {
			try {
				duration = Integer.parseInt(args[0]);
			} catch (NumberFormatException mfe) {
				System.out.println("Wrong command line argument: must be an integer number");
				System.out.println("The default duration 10000 milliseconds will be used");
			}
		}
		// Create the screen
		OthelloSplashScreen splashWindow = new OthelloSplashScreen(duration);
		// Show the Splash screen
		splashWindow.showSplashWindow();
		
		JFrame othelloFrame = new OthelloViewController();
		// Create and display the main application GUI
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				
				
				othelloFrame.setResizable(false);
				othelloFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				othelloFrame.setLocationRelativeTo(null);// screen center
				othelloFrame.setVisible(true);
				othelloFrame.setTitle("Maryam's Othello Client");
				othelloFrame.setMinimumSize(new Dimension(1050, 690)); //1050,750
				
			}
		});

	}
}

