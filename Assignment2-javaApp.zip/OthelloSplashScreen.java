
// Author: Maryam Afshar 040885113
// Assignment: 2
// Date: JuLY 24, 2021
// Professor: Daniel Cormier
// Purpose: To make the splash screen
// Class list: OthelloSplashScreen

package othello;

import java.awt.*;
import javax.swing.*;

/**
 * OthelloSplashScreen will create the splash screen
 * 
 * @author Maryam Afshar
 * @version 1
 * @see othello
 * @since "1.8.0_231"
 */

public class OthelloSplashScreen extends JWindow {

	private static final long serialVersionUID = 6248477390124803341L;
	private final int duration;

	public OthelloSplashScreen(int duration) {
		this.duration = duration;
	}

	/**
	 * Shows a splash screen in the center of the desktop for the amount of time
	 * given in the constructor.
	 */
	public void showSplashWindow() {
//create content pane
		JPanel content = new JPanel(new BorderLayout());
//  use the window content pane
//
		content.setBackground(Color.gray);

		int width = 734 + 10;
		int height = 263 + 10;
//
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
//
		int x = (screen.width - width) / 2;
		int y = (screen.height - height) / 2;

		setBounds(x, y, width, height);

		JLabel label = new JLabel(new ImageIcon(getClass().getResource("/pic/SplashSwing.png")));
		JLabel demo = new JLabel("Maryam Afshar", JLabel.CENTER);

		demo.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 14));
		content.add(label, BorderLayout.CENTER);
		content.add(demo, BorderLayout.SOUTH);

		// create custom RGB color
		Color customColor = new Color(44, 197, 211);
		content.setBorder(BorderFactory.createLineBorder(customColor, 10));

		setContentPane(content);

		setVisible(true);

		try {

			Thread.sleep(duration);
		} catch (Exception e) {
			e.printStackTrace();
		}

		dispose();

	}

}// end SplashScreenDemo class

