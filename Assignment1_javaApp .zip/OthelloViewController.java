//File name: OthelloViewController.java
//Author: Maryam Afshar 040885113
//Assignment: 1 
//Date: June 26, 2021
//Professor: Daniel Cormier
//Purpose: Make the othello game area
//Class list: OthelloViewController

package othello;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;

/**
 * OthelloViewController will create the sectors of the game
 * 
 * @author Maryam Afshar
 * @version 1
 * @see othello
 * @since "1.8.0_231"
 */

public class OthelloViewController extends JFrame {
	/**
	 * variable declaration for serial ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * variable declaration for aray for board
	 */
	public JLabel[][] othelloBoard = new JLabel[8][8];
	
	/**
	 * Panel for the board
	 */
	public JPanel board;

	/**
	 * purpose of constructor: all the sector creations is in constructor
	 */

	public OthelloViewController() {
		// creating 5 JPanel
		JPanel mainS = new JPanel();// Create the main section

		JPanel leftS = new JPanel();// create the left section

//start the Othello board
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if ((i + 1) % 2 != 0 && (j + 1) % 2 != 0) {

				}

				else if ((i + 1) % 2 == 0 && (j + 1) % 2 == 0) {

				}

			}
		}
		JPanel rightS = new JPanel();// create right section
		JPanel bottomS = new JPanel();// create bottom Section

		// start of creating 2 components of bottom section which is a button and
		// textField

		// Create a button in bottom section to submit
		JButton blackBox = new JButton("Submit");

		// set background color of button
		blackBox.setBackground(Color.black);

		// set color of text inside blackbox
		blackBox.setForeground(Color.RED);

		// create a textField at bottom part of main section
		JTextField bottomL = new JTextField();

		// create a borderLayout in main section
		mainS.setLayout(new BorderLayout());

		// set the background color to grey
		mainS.setBackground(new Color(220, 220, 220));

		// set the border color to grey and thickness to 5
		mainS.setBorder(BorderFactory.createLineBorder(Color.gray, 5));

		// create a borderLayout in bottom part of main section
		bottomS.setLayout(new BorderLayout());

		// add the black box to bottom section and be at right
		bottomS.add(blackBox, BorderLayout.EAST);

		// add the textField to bottom section and set it to be in center
		bottomS.add(bottomL, BorderLayout.CENTER);

		// add the bottom section to the main section and put it at the south of main
		// section
		mainS.add(bottomS, BorderLayout.SOUTH);
		add(mainS);

		// end of bottom section

		/**
		 * start of creating right section
		 * 
		 * create a borderLayout in right part of main section
		 */

		rightS.setLayout(new BorderLayout());

		// set a preferred size for right section
		rightS.setPreferredSize(new Dimension(450, 30));

		/**
		 * Creating three JPanel in right section creating a check box at the very top
		 * of right section of main
		 */

		JCheckBox right1 = new JCheckBox("Show Valid Moves");
		JPanel r1 = new JPanel();
		JPanel r2 = new JPanel();
		JPanel r3 = new JPanel();

		/**
		 * adding first part r1 to the right section creating new border layout in right
		 * section adding check box to first section
		 */
		rightS.add(r1, BorderLayout.NORTH);
		r1.setLayout(new BorderLayout());
		r1.add(right1);

		// Creating text area in part two of right section
		JTextArea blueText = new JTextArea("Player 1 initialized with 2 pieces.");

		blueText.setBackground(new Color(175, 175, 255));
		blueText.append("\nPlayer 2 initialized with 2 pieces.");
		blueText.setEditable(false);

		// add the blue text part at south of right sction
		rightS.add(r2, BorderLayout.SOUTH);

		// set background color
		r2.setBackground(new Color(175, 175, 255));

		// set size
		r2.setPreferredSize(new Dimension(450, 450));

		// add the blue text to south section in right
		r2.add(blueText);
		r2.setBorder(new MatteBorder(5, 0, 5, 0, Color.GRAY));

		/**
		 * start of center part of right section 3 parts in center part creating 3 part
		 * in r3
		 */
		JPanel r3L = new JPanel();
		JPanel r3R = new JPanel();
		JPanel r3C = new JPanel();

		// create 2 JPanel in right section of r3
		JPanel r3RN = new JPanel();
		JPanel r3RS = new JPanel();

		ImageIcon white = new ImageIcon(this.getClass().getResource("/pic/white.png"));

		// creating new JLabel
		JLabel whitePic = new JLabel(white);
		JTextField whiteNum = new JTextField("2");
		whiteNum.setBackground(new Color(220, 220, 220));
		whiteNum.setEditable(false);
		whiteNum.setBorder(null);

		r3RN.add(whitePic);
		r3RN.add(whiteNum);
		r3RN.setBackground(new Color(220, 220, 220));

		// creating image icon
		ImageIcon black = new ImageIcon(this.getClass().getResource("/pic/black.png"));
		JLabel blackPic = new JLabel(black);
		JTextField blackNum = new JTextField("2");

		// set the background color
		blackNum.setBackground(new Color(220, 220, 220));
		blackNum.setEditable(false);
		blackNum.setBorder(null);

		r3RS.add(blackPic);
		r3RS.add(blackNum);
		r3RS.setBackground(new Color(220, 220, 220));

		// creating grid layout with 3 rows and 1 column
		r3R.setLayout(new GridLayout(3, 1));

		// creating new JPanel
		JPanel e = new JPanel();
		e.setBackground(new Color(220, 220, 220));
		r3R.add(e);
		r3R.add(r3RN);
		r3R.add(r3RS);

		// creating grid layout at the center of r3
		r3C.setLayout(new GridLayout(3, 1));
		e = new JPanel();

		e.setBackground(new Color(220, 220, 220));
		r3C.add(e);

		/**creating text field
		 * 
		 */
		JTextField p1 = new JTextField("Player 1 Pieces:");
		p1.setEditable(false);
		p1.setBackground(new Color(220, 220, 220));
		p1.setBorder(null);

		/**
		 * create textField
		 */
		JTextField p2 = new JTextField("Player 2 Pieces:");
		p2.setEditable(false);
		p2.setBackground(new Color(220, 220, 220));
		p2.setBorder(null);

		r3C.add(p1);
		r3C.add(p2);

		r3L.setLayout(new GridLayout(3, 3, 3, 3));

		JButton empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		
		JButton up = new JButton(new ImageIcon(this.getClass().getResource("/pic/uparrow.png")));
		up.setPreferredSize(new Dimension(40, 40));
		up.setBackground(Color.WHITE);
		r3L.add(up);

		empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		JButton left = new JButton(new ImageIcon(this.getClass().getResource("/pic/leftarrow.png")));
		left.setPreferredSize(new Dimension(40, 40));
		left.setBackground(Color.WHITE);
		r3L.add(left);

		JButton move = new JButton("move");
		move.setPreferredSize(new Dimension(40, 40));
		move.setBackground(Color.WHITE);
		r3L.add(move);

		JButton right = new JButton(new ImageIcon(this.getClass().getResource("/pic/rightarrow.png")));
		right.setPreferredSize(new Dimension(40, 40));
		right.setBackground(Color.WHITE);
		r3L.add(right);

		empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		/**
		 * create new botton
		 */
		JButton down = new JButton(new ImageIcon(this.getClass().getResource("/pic/downarrow.png")));
		down.setBackground(Color.WHITE);
		down.setPreferredSize(new Dimension(40, 40));
		r3L.add(down);
  
		empty = new JButton("");
		empty.setBorderPainted(false);
		empty.setEnabled(false);
		empty.setBackground(new Color(220, 220, 220));
		r3L.add(empty); //

		r3L.setBackground(new Color(220, 220, 220));

		r3.setLayout(new FlowLayout());
		r3.setBackground(new Color(220, 220, 220));

		r3.add(r3L);
		r3.add(r3C);
		r3.add(r3R);

		r3.setBorder(new MatteBorder(5, 0, 0, 0, Color.GRAY));

		rightS.add(r3, BorderLayout.CENTER);

		rightS.setBorder(new MatteBorder(0, 5, 0, 0, Color.GRAY));
		mainS.add(rightS, BorderLayout.EAST);
		mainS.add(leftS, BorderLayout.WEST);

	}

	/**
	 * goal:this class should manage all buttons and the checkbox
	 * 
	 * @author Maryam Afshar
	 *
	 */
	class Controller {

		// startButton.addActionListener(new ActionListener()

	}
}
